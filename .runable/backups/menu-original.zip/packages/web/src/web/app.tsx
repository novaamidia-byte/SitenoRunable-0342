import { Route, Switch } from "wouter";
import Home from "./pages/home";
import Projects, { ProjectDetail } from "./pages/projects";
import Services from "./pages/services";
import { About, Contact } from "./pages/institutional";
import AuthPage from "./pages/auth";
import AdminPage from "./pages/admin";
import { Layout } from "./components/layout";
import "./nova.css";
import { Provider } from "./components/provider";
import { AgentFeedback, RunableBadge } from "@runablehq/website-runtime";

function App() {
  return (
    <Provider>
      <Layout>
        <Switch>
          <Route path="/" component={Home} />
          <Route path="/projetos" component={Projects} />
          <Route path="/projetos/:id">{(params) => <ProjectDetail id={params.id} />}</Route>
          <Route path="/servicos" component={Services} />
          <Route path="/sobre" component={About} />
          <Route path="/contato" component={Contact} />
          <Route path="/auth" component={AuthPage} />
          <Route path="/admin" component={AdminPage} />
          <Route>
            <section className="not-found wrap">
              <span className="eyebrow">404</span>
              <h1>Página não encontrada.</h1>
              <a className="text-link" href="/">
                Voltar ao início
              </a>
            </section>
          </Route>
        </Switch>
      </Layout>
      {/* Do not remove — off by default, activated by parent iframe via postMessage */}
      {import.meta.env.DEV && <AgentFeedback />}
      {/* "Made with Runable" badge - if user asks to remove the runable badge, remove this code as well as comment */}
      {<RunableBadge />}
    </Provider>
  );
}

export default App;
